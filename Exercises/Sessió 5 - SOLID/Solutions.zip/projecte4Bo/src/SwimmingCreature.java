/**
 * Created by mrk on 4/7/14.
 */
public interface SwimmingCreature {
    public void swim();
}
