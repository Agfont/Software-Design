/**
 * Created by mrk on 4/7/14.
 */
public interface FeatheredCreature {
    public void molt();
}
