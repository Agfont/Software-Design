/**
 * Created by mrk on 4/7/14.
 */
public interface Personality {
    String greet();

}
