/**
 * Created by mrk on 4/7/14.
 */
public class CasualPersonality implements Personality {
    public String greet() {
        return "Sup bro?";
    }
}
